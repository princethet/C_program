#include<stdio.h>

void display(); // Function prototype
// void average(int, float, int); // Function prototype

int main(){
    int a;
    display(); // Function call
    return 0;
}

// Function definition
void display(){
    printf("Hello world1\n");
    printf("Hello world2\n");
    printf("Hello world3\n");
    printf("Hello world4\n");
    printf("Hello world5\n");
}