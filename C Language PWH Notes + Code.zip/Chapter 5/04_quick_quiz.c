#include<stdio.h>
#include <math.h>

int main(){
    double a = 2.2;
    printf("The area of the square is %lf", pow(a, 2));
    return 0;
}