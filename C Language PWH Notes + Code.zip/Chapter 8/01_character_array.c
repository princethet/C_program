#include<stdio.h>

int main(){
    // char str1[] = {'H', 'a', 'r', 'r', 'y', '\0'};
    char str1[] = "Harry";
    printf("%s", str1);
    return 0;
}