#include<stdio.h>

int main(){
    char ch1[46];
    printf("Enter your name and see the magic\n");
    scanf("%s", ch1);
    printf("You name is %s", ch1);
    return 0;
}