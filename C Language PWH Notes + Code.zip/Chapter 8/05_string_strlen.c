#include<stdio.h>
#include <string.h>

int main(){
    char str1[] = "Harryy";
    printf("The length of this string is %d", strlen(str1));
    return 0;
}