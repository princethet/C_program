#include<stdio.h>
int main()
{
    int harry = 7;
    int Harry = 17;
    printf("Hello Harry");
    printf("Hello Harry");
    return(0);
}