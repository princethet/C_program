#include<stdio.h>
int main()
{
    int harry = -7;
    char harry2 = 'c';
    float harry3 = 5.23;
    int Harry = 17;
    printf("Hello Harry");
    printf("Hello Harry");
    return(0);
}