/*
Author: Harry
Place: India
*/
#include<stdio.h>

int main()
{  
    printf("Enter your number\n"); 
    int a;
    scanf("%d", &a);
    printf("Your number is %d", a);
    return 0; 
}