#include<stdio.h>

int main(){
    int r = 4;
    printf("The area of circle is %f", 3.14*r*r);
    int h = 5;
    printf("The volume of cylinder is %f", 3.14*r*r*h);
    return 0;

}