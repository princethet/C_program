/*
Author: Harry
Place: India
*/
#include<stdio.h>

int main()
{
    int a = 3;
    float b = 3.1;
    char c = 'c';
    // I want to write code to read the user mic 
    printf("Hello\n");
    printf("Hello I am learning C with harry\n");
    printf("This is an integer %d\n", a);
    printf("This is a floating point number %f\n", b);
    printf("This is a character %c\n", c);
    return 0; 
}