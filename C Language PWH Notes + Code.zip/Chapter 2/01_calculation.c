#include<stdio.h>

int main(){
    int a = 3.0/9;
    printf("The value of a is %d", a);
    return 0;
}