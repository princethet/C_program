#include<stdio.h>

int main(){
    // There are four major data types in C
    // 1. int - for storing integers
    // 2. float - single precision floating point number
    // 3. char - storing characters (enclosed in ') "A" is invalid; 'A' is valid
    // 4. double - double precision floating point number
    int a = 3^3;
    
    return 0;
}