#include<stdio.h>

int main(){
    // int a = 9+3*5-5;
    int a = 9/3*27-5;
    // 3 * 27 - 5
    // 76
    printf("Value of a is %d", a);
    return 0;
}