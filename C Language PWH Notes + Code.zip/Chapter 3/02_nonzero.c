#include<stdio.h>

int main(){
    if(23){
        printf("Any non zero value is evaluated to true ");
    }
    return 0;
}