#include<stdio.h>

int main(){
    int a = 34;
    int b = 2;
    if(a>7 && b<4){
        printf("yes");
    }
    return 0;
}