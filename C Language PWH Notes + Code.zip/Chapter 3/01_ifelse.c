#include<stdio.h>

int main(){
    int a = 2;
    if(a>4){
        printf("a is greater than 4");
    }
    else{
        printf("a is not greater than 4");
    }
    return 0;
}