#include<stdio.h>

int main(){
    int a = 10;
    if(a=11){
        printf("a is 11");
    }
    else{
        printf("a is 10");
    }
    return 0;
}