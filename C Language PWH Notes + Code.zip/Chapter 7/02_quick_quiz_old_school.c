#include<stdio.h>

int main(){
    int marks1, marks2, marks3, marks4, marks5;
    printf("Enter the score of student 1\n");
    scanf("%d", &marks1);
    printf("Enter the score of student 2\n");
    scanf("%d", &marks2);
    printf("Enter the score of student 3\n");
    scanf("%d", &marks3);
    printf("Enter the score of student 4\n");
    scanf("%d", &marks4);
    printf("Enter the score of student 5\n");
    scanf("%d", &marks5);

    printf("The score scored by student 1 is %d \n", marks1);
    printf("The score scored by student 2 is %d \n", marks2);
    printf("The score scored by student 3 is %d \n", marks3);
    printf("The score scored by student 4 is %d \n", marks4);
    printf("The score scored by student 5 is %d \n", marks5);
    return 0;
}