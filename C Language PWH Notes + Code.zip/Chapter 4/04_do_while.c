#include<stdio.h>

int main(){
    int i = 1;
    do{
        printf("The value of i is %d", i);
        i++;
    }while(i<5);


    return 0;
}