#include<stdio.h>

int main(){
    for (int i = 5; i; i--)
    {
       printf("The value of i is %d\n", i);  
    }
    
    return 0;
}
// Dry run for the decrementing for loop
// 5 i=4
// 4 i=3
// 3 i=2
// 2 i=1
// 1 i=0
