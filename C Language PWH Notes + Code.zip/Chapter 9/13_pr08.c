#include<stdio.h>

struct bank{
    int accountNo;
    char name[20];
    float balance;
    char branchCode[15];
};

int main(){
    
    return 0;
}